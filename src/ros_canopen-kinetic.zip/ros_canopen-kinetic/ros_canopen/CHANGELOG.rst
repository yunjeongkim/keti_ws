^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_canopen
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.6 (2017-08-30)
------------------

0.7.5 (2017-05-29)
------------------

0.7.4 (2017-04-25)
------------------

0.7.3 (2017-04-25)
------------------

0.7.2 (2017-03-28)
------------------

0.7.1 (2017-03-20)
------------------

0.7.0 (2016-12-13)
------------------

0.6.5 (2016-12-10)
------------------
* updated metapackage
  * format 2
  * updated maintaner
  * added new packages
* update package URLs
* Contributors: Mathias Lüdtke

0.6.4 (2015-07-03)
------------------

0.6.3 (2015-06-30)
------------------

0.6.2 (2014-12-18)
------------------
* remove canopen_test_utils from metapackage
* Contributors: Florian Weisshardt

0.6.1 (2014-12-15)
------------------
* add metapackage
* Contributors: Florian Weisshardt
