var class_point_handler =
[
    [ "getDistance", "class_point_handler.html#ae5d42991d2fe2a2e89afc4defc9158e1", null ],
    [ "getDistance", "class_point_handler.html#ae5d42991d2fe2a2e89afc4defc9158e1", null ],
    [ "point_", "class_point_handler.html#ad95d3d370852a0dfb97f099e01934f6a", null ]
];