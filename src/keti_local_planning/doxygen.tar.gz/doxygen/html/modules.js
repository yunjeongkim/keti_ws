var modules =
[
    [ "main", "group___main_group.html", "group___main_group" ],
    [ "algorithm", "group___algorithm_group.html", null ],
    [ "data", "group___data_group.html", "group___data_group" ],
    [ "data handling", "group___data_handling_group.html", "group___data_handling_group" ]
];