var indexSectionsWithContent =
{
  0: "acdfgiklmnprsvwxyz~",
  1: "acglprw",
  2: "acgklmprw",
  3: "acfgilmprsw~",
  4: "acdlnprsvwxyz",
  5: "adm",
  6: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수",
  5: "그룹들",
  6: "페이지들"
};

