var group___data_group =
[
    [ "GPSPoint", "class_g_p_s_point.html", [
      [ "GPSPoint", "class_g_p_s_point.html#a7a635f12f124e516210755b0974ee1d4", null ],
      [ "GPSPoint", "class_g_p_s_point.html#aab0d3a5aaee6586b615f55a82c17a10d", null ],
      [ "getPoint", "class_g_p_s_point.html#aa02789544161ef0bcc40a24972f1b365", null ],
      [ "a_", "class_g_p_s_point.html#ac4652d53d65aeb605f7eb35128a5ab90", null ],
      [ "x_", "class_g_p_s_point.html#ad4b7325afe1ca0fcf8d2ef284ab9b62c", null ],
      [ "y_", "class_g_p_s_point.html#ad41d0e7a93f8766181402ce25af798fe", null ],
      [ "z_", "class_g_p_s_point.html#aa6622ef5c0c58fa1b59c1d5b77fe020c", null ]
    ] ],
    [ "WayPoint", "class_way_point.html", [
      [ "WayPoint", "class_way_point.html#a0388a615719454d38b5a8160d8058550", null ],
      [ "WayPoint", "class_way_point.html#a0a5358f5f8894bf9bc0279e4758f712d", null ],
      [ "WayPoint", "class_way_point.html#afb55bf3008e6df983912ca195a4994e1", null ],
      [ "getDistance", "class_way_point.html#ad2b8fa2161cb6dfa5d7ff8f993f1c62c", null ],
      [ "getPoint", "class_way_point.html#a3d0e6433de5c74a13be5f6f276d0a71d", null ],
      [ "pos_", "class_way_point.html#aef2ddd64bef263157f27d69e40f1e7e3", null ],
      [ "v_", "class_way_point.html#aecad0ca0d0dbb03cf02d92d31e5e99bd", null ]
    ] ]
];