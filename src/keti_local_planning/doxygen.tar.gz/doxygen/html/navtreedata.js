var NAVTREE =
[
  [ "KetiWS", "index.html", [
    [ "Keti Local Planning Package", "index.html", [
      [ "Introduction", "index.html#Introduction", null ]
    ] ],
    [ "모듈", "modules.html", "modules" ],
    [ "클래스", "annotated.html", [
      [ "클래스 목록", "annotated.html", "annotated_dup" ],
      [ "클래스 색인", "classes.html", null ],
      [ "클래스 멤버", "functions.html", [
        [ "모두", "functions.html", null ],
        [ "함수", "functions_func.html", null ],
        [ "변수", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "파일들", null, [
      [ "파일 목록", "files.html", "files" ],
      [ "파일 멤버", "globals.html", [
        [ "모두", "globals.html", null ],
        [ "함수", "globals_func.html", null ],
        [ "변수", "globals_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"angle__utils_8cpp.html"
];

var SYNCONMSG = '패널 동기화를 비활성화하기 위해 클릭하십시오';
var SYNCOFFMSG = '패널 동기화를 활성화하기 위해 클릭하십시오';