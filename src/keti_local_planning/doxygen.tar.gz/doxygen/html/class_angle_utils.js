var class_angle_utils =
[
    [ "AngleUtils", "class_angle_utils.html#a244b7e39d429d0667180ee1f6c4688dc", null ],
    [ "~AngleUtils", "class_angle_utils.html#afd7d97d10e25e67dfad8a3700168f796", null ],
    [ "AngleBetweenTwoAnglesPositive", "class_angle_utils.html#aa9a3fb876a9b6d446a8033d2f901bb73", null ],
    [ "FixNegativeAngle", "class_angle_utils.html#a27d9bd3a5b5816f9b94dbdadc785a75d", null ],
    [ "GetCircularAngle", "class_angle_utils.html#a5a51b312ed27e10ab9af2e092a897da7", null ],
    [ "InverseAngle", "class_angle_utils.html#a90a3b153450f72621fa4d601630f7999", null ],
    [ "SplitPositiveAngle", "class_angle_utils.html#a91f3e34c9e1e35788d44a2f6bc5bc206", null ]
];