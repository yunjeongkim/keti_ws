var math__constant_8h =
[
    [ "max", "math__constant_8h.html#a0ddaec2f52f526234b051c9dff699a5f", null ],
    [ "min", "math__constant_8h.html#a83c0028e8e5f11951b04025d01ffe408", null ],
    [ "sign", "math__constant_8h.html#a5e195fe2ba1896ebf32b3c92c0995315", null ],
    [ "DEG2RAD", "math__constant_8h.html#a3990c92eaf1a7084542e083950900d47", null ],
    [ "RAD2DEG", "math__constant_8h.html#ada7628b7b7ccf0546436b9904cd76cd1", null ]
];