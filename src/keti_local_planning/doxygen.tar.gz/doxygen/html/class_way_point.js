var class_way_point =
[
    [ "WayPoint", "class_way_point.html#a0388a615719454d38b5a8160d8058550", null ],
    [ "WayPoint", "class_way_point.html#a0a5358f5f8894bf9bc0279e4758f712d", null ],
    [ "WayPoint", "class_way_point.html#afb55bf3008e6df983912ca195a4994e1", null ],
    [ "getDistance", "class_way_point.html#ad2b8fa2161cb6dfa5d7ff8f993f1c62c", null ],
    [ "getPoint", "class_way_point.html#a3d0e6433de5c74a13be5f6f276d0a71d", null ],
    [ "pos_", "class_way_point.html#aef2ddd64bef263157f27d69e40f1e7e3", null ],
    [ "v_", "class_way_point.html#aecad0ca0d0dbb03cf02d92d31e5e99bd", null ]
];